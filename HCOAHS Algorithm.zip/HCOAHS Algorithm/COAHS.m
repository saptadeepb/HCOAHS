% Hybrid Crayfish Optimization Algorithm (COA) with Harmony Search (HS)
% By Binanda Maiti, and Dr. Saptadeep Biswas 
% Article: Adaptive Hybrid Crayfish - Harmonic Search Metaheuristic for Robust Feature Selection in Supervised Classification
% Joournal: Cluster Computing 
% function [best_fun11, best_position11, curve_f11, global_Cov11] = COAHS(N, T, lb, ub, dim, fobj, fhd)
% function [best_fun11, best_position11, curve_f11, global_Cov11] = COAHS(N, T, lb, ub, dim, fobj, fhd, HMCR)
function [best_fun11, best_position11, curve_f11, global_Cov11] = COAHS(N, T, lb, ub, dim, fobj, fhd, HMCR, PAR, HMS)

    disp('COA-HS working');
    curve_f11 = zeros(1, T); 
    global_Cov11 = zeros(1, T);

    %% COA Initialization
    X = initialization(N, dim, ub, lb);
    Best_fitness = inf;
    best_position11 = zeros(1, dim);
    fitness_f = zeros(1, N);

    for i = 1:N
        fitness_f(i) = feval(fhd, X(i,:)', fobj);
        if fitness_f(i) < Best_fitness
            Best_fitness = fitness_f(i);
            best_position11 = X(i,:);
        end
    end

    global_position = best_position11; 
    global_fitness = Best_fitness;
    curve_f11(1) = Best_fitness;

    %% Harmony Search Initialization
    cPop = N;
    nNew = N;
    HMCR = 0.9;
    PAR = 0.1;
    FW = 0.02 * mean(ub - lb);
    FW_damp = 0.995;

    empty_harmony.Position = [];
    empty_harmony.Cost = [];

    HM = repmat(empty_harmony, cPop, 1);
    for i = 1:cPop
        HM(i).Position = lb + rand(1, dim) .* (ub - lb);
        HM(i).Cost = feval(fhd, HM(i).Position', fobj);
    end
    [~, SortOrder] = sort([HM.Cost]);
    HM = HM(SortOrder);
    BestSol = HM(1);

    %% Main Loop
    for t = 1:T
        C = 2 - (t / T);
        temp = rand * 15 + 20;
        xf = (best_position11 + global_position) / 2;
        Xfood = best_position11;

        for i = 1:N
            if temp > 30
                if rand < 0.5
                    Xnew(i,:) = X(i,:) + C * rand(1, dim) .* (xf - X(i,:));
                else
                    for j = 1:dim
                        z = randi(N);
                        Xnew(i,j) = X(i,j) - X(z,j) + xf(j);
                    end
                end
            else
                P = 3 * rand * fitness_f(i) / (feval(fhd, Xfood', fobj) + eps);
                if P > 2
                    Xfood = exp(-1 / P) .* Xfood;
                    for j = 1:dim
                        Xnew(i,j) = X(i,j) + cos(2*pi*rand)*Xfood(j)*p_obj(temp) - sin(2*pi*rand)*Xfood(j)*p_obj(temp);
                    end
                else
                    Xnew(i,:) = (X(i,:) - Xfood) * p_obj(temp) + p_obj(temp) .* rand(1, dim) .* X(i,:);
                end
            end
        end

        % Boundary Control
        Xnew = max(repmat(lb, N, 1), min(repmat(ub, N, 1), Xnew));

        % Evaluate and update COA
        for i = 1:N
            new_fitness = feval(fhd, Xnew(i,:)', fobj);
            if new_fitness < global_fitness
                global_fitness = new_fitness;
                global_position = Xnew(i,:);
            end
            if new_fitness < fitness_f(i)
                fitness_f(i) = new_fitness;
                X(i,:) = Xnew(i,:);
                if new_fitness < Best_fitness
                    Best_fitness = new_fitness;
                    best_position11 = X(i,:);
                end
            end
        end

        %% Harmony Search Process
        NEW = repmat(empty_harmony, nNew, 1);
        for k = 1:nNew
            NEW(k).Position = lb + rand(1, dim) .* (ub - lb);
            for j = 1:dim
                if rand <= HMCR
                    idx = randi([1 cPop]);
                    NEW(k).Position(j) = HM(idx).Position(j);
                end
                if rand <= PAR
                    DELTA = FW * randn();
                    NEW(k).Position(j) = NEW(k).Position(j) + DELTA;
                end
            end
            NEW(k).Position = max(lb, min(ub, NEW(k).Position));
            NEW(k).Cost = feval(fhd, NEW(k).Position', fobj);
        end

        HM = [HM; NEW];
        [~, SortOrder] = sort([HM.Cost]);
        HM = HM(SortOrder);
        HM = HM(1:cPop);
        BestSol = HM(1);
        FW = FW * FW_damp;

        if BestSol.Cost < Best_fitness
            Best_fitness = BestSol.Cost;
            best_position11 = BestSol.Position;
        end

        curve_f11(t) = Best_fitness;
        global_Cov11(t) = global_fitness;

        if mod(t,100)==0
            disp(["COA-HS iter " num2str(t) ": " num2str(Best_fitness)]);
        end
    end

    best_fun11 = Best_fitness;
end

function y = p_obj(x)
    y = 0.2*(1/(sqrt(2*pi)*3))*exp(-(x-25).^2/(2*3.^2));
end
