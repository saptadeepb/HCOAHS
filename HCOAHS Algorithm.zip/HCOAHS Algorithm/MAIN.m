clear all
clc
% Hybrid Crayfish Optimization Algorithm (COA) with Harmony Search (HS)
% By Binanda Maiti, and Dr. Saptadeep Biswas 
% Article: Adaptive Hybrid Crayfish - Harmonic Search Metaheuristic for Robust Feature Selection in Supervised Classification
% Joournal: Cluster Computing 

N = 30;    % Population size or number of agents
T = 1000;  % Number of iterations

Fun_id = 1:30;  % Function IDs from 1 to 30
cec = 4;        % Set to 4 for CEC-2022

if cec == 4
    fhd = str2func('cec22_func');  % Use CEC-2022 benchmark functions
    benchmarksType = 'cec22_func';
else
    error('This script is configured to run only for CEC-2022 (cec=4).');
end

for i = 1:12   % Only 12 benchmark functions in CEC-2022
    disp(['Problem number: ', num2str(i)]);
    
    [lb, ub, dim] = Get_Functions_detailsCEC(Fun_id(i));
    fobj = Fun_id(i);
    
    % Run your optimization algorithm
    [best_fun11, best_position11, curve_f11, global_Cov11] = COAHS(N, T, lb, ub, dim, fobj, fhd);
    
    % Plot convergence curve for this function
    figure(i);
    plot(1:T, curve_f11, 'Color', "#000000", 'LineWidth', 2);
    title(['Convergence Curve - CEC 2022 F' num2str(i)]);
    xlabel('Iterations');
    ylabel('Fitness Value');
    grid on;
    set(gca, 'YScale', 'log');  % Optional: better visualization
end
